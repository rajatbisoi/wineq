from os import name
from setuptools import setup , find_packages

setup(
    name = 'src' ,
    version = '0.0.1',
    description = "its a wine quality app pakage",
    aurthor = 'RajaTBisoI',
    packages = find_packages(),
    licesnse = "MIT"
)